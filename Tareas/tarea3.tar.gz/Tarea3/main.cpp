#include "iostream"
#include "cmath"
#include "Square.cpp"
#include "Square.h"
using namespace std;


int main(){
    float lado;
    int orden;

    cout<<"Ingrese el valor del lado del cuadrado superior: "<<endl;
    cin>>lado;

    cout<<"Ingrese el orden de la suma: "<<endl;
    cin>>orden;

    Squares sq = Squares(lado, orden); //Se instancia la clase
    sq.Area();
    sq.Perimetro();
}