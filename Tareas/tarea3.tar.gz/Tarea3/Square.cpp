#include "iostream"
#include "Square.h"
#include "cmath"
using namespace std;

void Squares::Area(){
    float suma = 0;

    for(int i = 0; i <= Orden; i++){

        float y = Lado/pow(2, i);
        suma = suma + y;

    }

    cout<<"La suma de areas es aproximadamente: "<<suma<<endl;
};

void Squares::Perimetro(){
    float suma = 0;

    for(int i = 0; i <= Orden; i++){

        float y = 4*Lado/pow(sqrt(2), i);
        suma = suma + y;

    }

    cout<<"La suma de areas es aproximadamente: "<<suma<<endl;
};