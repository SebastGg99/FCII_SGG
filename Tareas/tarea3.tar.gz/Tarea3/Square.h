#include "iostream"
#include "cmath"
using namespace std;

//Se declara la clase
class Squares{

    private: //Atributos
        float Lado;
        int Orden;

    public: //Métodos
        Squares(float, int);
        void Area();
        void Perimetro();

};

//Se crean las instancias
Squares::Squares(float lado, int orden){
    Lado = lado;
    Orden = orden;

}